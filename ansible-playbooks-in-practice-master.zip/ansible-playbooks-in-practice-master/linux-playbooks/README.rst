**************************************************
All Linux playbooks will be placed in this folder.
**************************************************

* `This playbook creates Ansible environment for all Linux servers. <https://github.com/jamalshahverdiev/ansible-playbooks-in-practice/tree/master/linux-playbooks/first-linux-playbook>`_
* `Ansible playbooks Install and Configure Keycloak with MySQL database. <https://github.com/jamalshahverdiev/ansible-playbooks-in-practice/tree/master/linux-playbooks/ansible-keycloak-mysql>`_
