#### With the these codes you will install and configure KeyCloak with MySQL server.

##### Just execute the following command to install and configure all servers (We need to input password for the Ansible-Vault):
```bash
$ git clone https://github.com/salmanaghayev/ansible-task.git && cd ansible-task
$ vagrant up
```

##### After deployment you can open http://10.1.42.102:9990 address in your browser with "admin" login and password.
