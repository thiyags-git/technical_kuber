*************************************************************
In this repository I will store all type of ansible playbooks
*************************************************************

* `Ansible Cisco playbook list <https://github.com/jamalshahverdiev/ansible-playbooks-in-practice/tree/master/cisco-playbooks>`_

* `Ansible Linux playbook list <https://github.com/jamalshahverdiev/ansible-playbooks-in-practice/tree/master/linux-playbooks>`_
