**************************************************
All Cisco playbooks will be placed in this folder
**************************************************

* `All useful commands to use in Cisco IOS <https://github.com/jamalshahverdiev/ansible-playbooks-in-practice/tree/master/cisco-playbooks/cisco-daily-using-playbook>`_
